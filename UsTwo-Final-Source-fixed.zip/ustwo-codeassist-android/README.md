# UsTwo Android app (updated project)

Native Java Android app for application ID `com.ustwo.app`. Includes CameraX photo/video capture, theme switching, filter/tint previews, decorative flower/heart overlays, photo filter tinting on saved images, Firebase Authentication, per-account Firestore notes, and Bambi Space local voice memos with Firebase Storage upload.

## Build with GitHub Actions
1. Upload the contents of this project folder into your existing repository, preserving `.github/workflows/build.yml`.
2. `app/google-services.json` is included for Firebase project `ustwo-6d35b` and package `com.ustwo.app`.
3. Push to GitHub; the Actions workflow builds `app/build/outputs/apk/debug/app-debug.apk`.

## Firebase console setup required
- In Firebase Authentication, enable Email/Password provider.
- Create a Cloud Firestore database.
- Enable Firebase Storage.
- Deploy security rules before using real/private data. Suggested starting rules below only allow signed-in users to access their own UID folder/documents; partner sharing is not yet implemented.

### Firestore rules (starter)
```text
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

### Storage rules (starter)
```text
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{uid}/{allPaths=**} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```

## Honest feature notes
- The filters include color tints and decorative emoji overlays. Tulip crown/flower placement is not face-tracked AR; actual facial tracking needs a dedicated face-landmark/AR implementation.
- Photo tints are applied to saved photos. Video recording saves the camera stream, but filter overlays are preview-only and are not composited into recorded videos.
- Bambi Space can record a local voice memo and upload that memo plus metadata to the signed-in user's private Firebase path. Partner sharing, audio browser/playback UI, existing-file uploads and moderation are not yet complete.
- Firestore notes are per-user, not shared with a partner until invitation/linking and corresponding security rules are implemented.
- Build was not executed in this environment; GitHub Actions must verify compilation. Check the workflow log for any Gradle errors.
