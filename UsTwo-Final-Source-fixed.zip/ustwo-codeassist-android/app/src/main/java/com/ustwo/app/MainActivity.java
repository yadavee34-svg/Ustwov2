package com.ustwo.app;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.VideoView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class MainActivity extends ComponentActivity {
    private int theme=0; // 0 pink, 1 dark, 2 cream
    private int pink=Color.rgb(255,111,145), deep=Color.rgb(233,79,120), pale=Color.rgb(255,247,249), ink=Color.rgb(52,42,45), muted=Color.rgb(138,122,128);
    private FrameLayout root;
    private PreviewView previewView;
    private View tint;
    private TextView decorations, status, record;
    private LinearLayout filterBar;
    private VideoCapture<Recorder> videoCapture;
    private ImageCapture imageCapture;
    private Camera camera;
    private Recording recording;
    private CameraSelector selector=CameraSelector.DEFAULT_FRONT_CAMERA;
    private boolean recordingNow=false, cameraScreen=false, effectsOn=true, flashOn=false;
    private int filterIndex=0, intensity=55;
    private Uri lastUri;
    private File voiceFile;
    private Uri selectedAudioUri;
    private MediaRecorder mediaRecorder;
    private boolean voiceRecording=false;
    private final Handler handler=new Handler();
    private final String[] filterNames={"Natural","Dreamy Glow","Tulip Crown","Floating Tulips","Tiny Tulips","Hearts & Sparkles","Butterfly","Angel Glow","Vintage Film","Cinematic","B&W","Golden Hour","Retro Grain","Blur & Bokeh"};
    private final int[] filterColors={Color.TRANSPARENT,Color.argb(65,207,171,255),Color.argb(35,255,135,185),Color.argb(28,255,172,208),Color.argb(20,255,130,175),Color.argb(28,255,80,150),Color.argb(22,180,230,255),Color.argb(45,255,245,255),Color.argb(65,85,55,48),Color.argb(48,32,42,66),Color.argb(95,0,0,0),Color.argb(48,255,165,55),Color.argb(38,75,45,30),Color.argb(30,180,200,255)};
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private final ActivityResultLauncher<String[]> permissionLauncher=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result->{
        if(Boolean.TRUE.equals(result.get(Manifest.permission.CAMERA))) showCamera();
        else toast("Camera permission is needed to use the camera.");
    });

    @Override public void onCreate(Bundle b){super.onCreate(b); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance(); storage=FirebaseStorage.getInstance(); applyTheme(); home();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void applyTheme(){
        if(theme==0){pink=Color.rgb(255,111,145);deep=Color.rgb(233,79,120);pale=Color.rgb(255,247,249);ink=Color.rgb(52,42,45);muted=Color.rgb(138,122,128);}
        else if(theme==1){pink=Color.rgb(183,120,255);deep=Color.rgb(130,73,220);pale=Color.rgb(23,20,32);ink=Color.rgb(249,244,255);muted=Color.rgb(183,171,199);}
        else{pink=Color.rgb(192,104,115);deep=Color.rgb(159,76,92);pale=Color.rgb(250,245,233);ink=Color.rgb(66,53,48);muted=Color.rgb(139,121,109);}
    }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackground(shape(pink,18));b.setOnClickListener(v->r.run());return b;}
    private void setRoot(View v){root=new FrameLayout(this);root.setBackgroundColor(pale);root.setFitsSystemWindows(true);root.addView(v,new FrameLayout.LayoutParams(-1,-1));setContentView(root);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private LinearLayout page(String heading){LinearLayout p=col();p.setPadding(dp(20),dp(18),dp(20),dp(22));p.setBackgroundColor(pale);TextView h=text(heading,27,ink,true);p.addView(h);return p;}
    private void spacer(LinearLayout p,int h){View v=new View(this);p.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private void home(){
        cameraScreen=false;LinearLayout p=page("UsTwo ♡");p.addView(text("Our little world, in every moment.",14,muted,false));spacer(p,18);
        TextView hero=text("A LITTLE REMINDER\nEven miles apart, we share the little things. 💗",21,ink,true);hero.setPadding(dp(16),dp(20),dp(16),dp(20));hero.setBackground(shape(theme==1?Color.rgb(54,37,70):theme==2?Color.rgb(242,224,211):Color.rgb(255,226,231),22));p.addView(hero);
        spacer(p,18);p.addView(button("◎  Open camera & filters",this::requestCamera));spacer(p,8);p.addView(button("🎵  Bambi Space · Covers & voice memos",this::bambiSpace));spacer(p,8);p.addView(button("♡  Shared memories & notes",this::memories));spacer(p,8);p.addView(button("✦  Switch app theme",this::chooseTheme));spacer(p,8);p.addView(button(auth.getCurrentUser()==null?"Sign in / Create account":"Account · "+auth.getCurrentUser().getEmail(),this::authScreen));spacer(p,8);p.addView(button("▶  Preview last recording",this::playLast));
        spacer(p,14);p.addView(text("Camera media is saved on this device. Cloud sharing requires sign-in and Firebase security rules.",12,muted,false));setRoot(p);
    }
    private void chooseTheme(){String[] choices={"Romantic Pink & Lavender","Dark Premium Purple","Minimal Cream & Rose"};new android.app.AlertDialog.Builder(this).setTitle("Choose your UsTwo theme").setSingleChoiceItems(choices,theme,(d,w)->{theme=w;applyTheme();d.dismiss();home();}).setNegativeButton("Cancel",null).show();}
    private void requestCamera(){boolean cam=ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED;boolean mic=ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED;if(cam&&mic)showCamera();else permissionLauncher.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO});}
    private void showCamera(){
        cameraScreen=true;root=new FrameLayout(this);root.setBackgroundColor(Color.BLACK);previewView=new PreviewView(this);previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);root.addView(previewView,new FrameLayout.LayoutParams(-1,-1));
        tint=new View(this);tint.setBackgroundColor(filterColors[filterIndex]);root.addView(tint,new FrameLayout.LayoutParams(-1,-1));
        decorations=text("🌷        ✦        🌷\n\n     ♡      🦋      ♡",30,Color.rgb(255,178,211),true);decorations.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(-1,dp(180),Gravity.TOP);ep.topMargin=dp(78);root.addView(decorations,ep);
        LinearLayout panel=col();panel.setPadding(dp(12),dp(8),dp(12),dp(12));panel.setBackgroundColor(Color.argb(218,18,13,24));root.addView(panel,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));
        LinearLayout top=row();panel.addView(top);TextView close=text("×",30,Color.WHITE,false);close.setGravity(Gravity.CENTER);top.addView(close,new LinearLayout.LayoutParams(dp(42),dp(42)));close.setOnClickListener(v->{stopIfNeeded();home();});status=text("1080p · "+filterNames[filterIndex],12,Color.WHITE,true);top.addView(status,new LinearLayout.LayoutParams(0,-2,1));TextView flip=text("↻ Flip",14,Color.WHITE,true);top.addView(flip);flip.setPadding(dp(8),dp(8),dp(8),dp(8));flip.setOnClickListener(v->flipCamera());
        filterBar=new LinearLayout(this);filterBar.setGravity(Gravity.CENTER);filterBar.setOrientation(LinearLayout.HORIZONTAL);panel.addView(filterBar);for(int i=0;i<filterNames.length;i++){final int n=i;TextView f=text(filterNames[i],10,i==filterIndex?pink:Color.WHITE,i==filterIndex);f.setGravity(Gravity.CENTER);f.setPadding(dp(8),dp(10),dp(8),dp(10));filterBar.addView(f,new LinearLayout.LayoutParams(-2,-2));f.setOnClickListener(v->applyFilter(n));}
        TextView intensityLabel=text("Filter intensity",11,Color.WHITE,false);panel.addView(intensityLabel);SeekBar intensityBar=new SeekBar(this);intensityBar.setMax(100);intensityBar.setProgress(intensity);panel.addView(intensityBar);intensityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int value,boolean user){intensity=value;applyTint();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        LinearLayout actions=row();actions.setGravity(Gravity.CENTER);panel.addView(actions);TextView effect=text(effectsOn?"🌷 Effects":"Effects off",12,Color.WHITE,true);effect.setGravity(Gravity.CENTER);actions.addView(effect,new LinearLayout.LayoutParams(0,dp(55),1));effect.setOnClickListener(v->{effectsOn=!effectsOn;decorations.setVisibility(effectsOn?View.VISIBLE:View.GONE);effect.setText(effectsOn?"🌷 Effects":"Effects off");});TextView snap=text("◉ Photo",15,Color.WHITE,true);snap.setGravity(Gravity.CENTER);actions.addView(snap,new LinearLayout.LayoutParams(0,dp(55),1));snap.setOnClickListener(v->takePhoto());record=text("● Video",14,pink,true);record.setGravity(Gravity.CENTER);actions.addView(record,new LinearLayout.LayoutParams(0,dp(55),1));record.setOnClickListener(v->{if(recordingNow)stopRecording();else startRecording();});
        LinearLayout tools=row();tools.setGravity(Gravity.CENTER);panel.addView(tools);TextView flash=text("⚡ Flash",12,Color.WHITE,true);tools.addView(flash,new LinearLayout.LayoutParams(0,dp(38),1));flash.setOnClickListener(v->{flashOn=!flashOn;if(camera!=null&&camera.getCameraInfo().hasFlashUnit())camera.getCameraControl().enableTorch(flashOn);else toast("Flash isn't available on this camera.");flash.setText(flashOn?"⚡ Flash on":"⚡ Flash");});TextView zoom=text("Zoom −",12,Color.WHITE,true);tools.addView(zoom,new LinearLayout.LayoutParams(0,dp(38),1));zoom.setOnClickListener(v->{if(camera!=null){float current=camera.getCameraInfo().getZoomState().getValue().getZoomRatio();float max=camera.getCameraInfo().getZoomState().getValue().getMaxZoomRatio();camera.getCameraControl().setZoomRatio(current>=max?1f:Math.min(max,current+0.5f));zoom.setText("Zoom "+(current>=max?"+":"−"));}});TextView timer=text("⏱ Timer",12,Color.WHITE,true);tools.addView(timer,new LinearLayout.LayoutParams(0,dp(38),1));timer.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Photo timer").setItems(new String[]{"Take now","3 seconds","5 seconds","10 seconds"},(d,w)->{int seconds=w==0?0:w==1?3:w==2?5:10;handler.postDelayed(this::takePhoto,seconds*1000L);if(seconds>0)toast("Photo in "+seconds+" seconds…");}).show());panel.addView(button("Preview last recording",this::playLast));setContentView(root);startCamera();
    }
    private void applyTint(){if(tint!=null){int c=filterColors[filterIndex];int alpha=Color.alpha(c)*intensity/100;tint.setBackgroundColor(Color.argb(alpha,Color.red(c),Color.green(c),Color.blue(c)));}if(status!=null)status.setText("1080p · "+filterNames[filterIndex]);if(filterBar!=null)for(int i=0;i<filterBar.getChildCount();i++){TextView t=(TextView)filterBar.getChildAt(i);t.setTextColor(i==filterIndex?pink:Color.WHITE);t.setTypeface(null,i==filterIndex?Typeface.BOLD:Typeface.NORMAL);}}
    private void applyFilter(int n){filterIndex=n;applyTint();if(decorations!=null){String[] overlays={"","✦       ♡       ✦","🌷          🌷","🌷     🌸     🌷","🌷      ♡      🌷","♥      ✦      ♥","🦋       🦋       🦋","✧     ♡     ✧","✦      Film      ✦","✧   CINEMATIC   ✧","B&W","☀       ✦       ☀","✦      Grain      ✦","✧     bokeh     ✧"};decorations.setText(overlays[n]);decorations.setVisibility(effectsOn&&n!=0?View.VISIBLE:effectsOn?View.VISIBLE:View.GONE);} }
    private void startCamera(){if(!cameraScreen||previewView==null)return;ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);future.addListener(()->{try{ProcessCameraProvider provider=future.get();Preview preview=new Preview.Builder().build();preview.setSurfaceProvider(previewView.getSurfaceProvider());Recorder recorder=new Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD)).build();videoCapture=VideoCapture.withOutput(recorder);imageCapture=new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();provider.unbindAll();camera=provider.bindToLifecycle(this,selector,preview,imageCapture,videoCapture);applyTint();}catch(ExecutionException|InterruptedException e){toast("Camera failed to start.");}catch(Exception e){toast("Camera error: "+e.getMessage());}},ContextCompat.getMainExecutor(this));}
    private void flipCamera(){selector=selector==CameraSelector.DEFAULT_FRONT_CAMERA?CameraSelector.DEFAULT_BACK_CAMERA:CameraSelector.DEFAULT_FRONT_CAMERA;startCamera();}
    private void takePhoto(){if(imageCapture==null){toast("Camera is still starting.");return;}String name="UsTwo_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".jpg";ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.DISPLAY_NAME,name);cv.put(MediaStore.MediaColumns.MIME_TYPE,"image/jpeg");cv.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/UsTwo");ImageCapture.OutputFileOptions options=new ImageCapture.OutputFileOptions.Builder(getContentResolver(),MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv).build();imageCapture.takePicture(options,ContextCompat.getMainExecutor(this),new ImageCapture.OnImageSavedCallback(){public void onImageSaved(ImageCapture.OutputFileResults result){lastUri=result.getSavedUri();if(lastUri!=null&&filterIndex!=0)applyFilterToSavedImage(lastUri);toast("Photo saved in Pictures/UsTwo");}public void onError(ImageCaptureException e){toast("Photo failed: "+e.getMessage());}});}
    private void applyFilterToSavedImage(Uri uri){try{Bitmap source=BitmapFactory.decodeStream(getContentResolver().openInputStream(uri));if(source==null)return;Bitmap mutable=source.copy(Bitmap.Config.ARGB_8888,true);Canvas canvas=new Canvas(mutable);Paint paint=new Paint();int c=filterColors[filterIndex];paint.setColor(Color.argb(Color.alpha(c)*intensity/100,Color.red(c),Color.green(c),Color.blue(c)));canvas.drawRect(0,0,mutable.getWidth(),mutable.getHeight(),paint);if(filterIndex==10){Paint gray=new Paint();gray.setColorFilter(new android.graphics.ColorMatrixColorFilter(new android.graphics.ColorMatrix(new float[]{.213f,.715f,.072f,0,0,.213f,.715f,.072f,0,0,.213f,.715f,.072f,0,0,0,0,0,1,0})));Bitmap grayBmp=Bitmap.createBitmap(mutable.getWidth(),mutable.getHeight(),Bitmap.Config.ARGB_8888);new Canvas(grayBmp).drawBitmap(source,0,0,gray);mutable=grayBmp;}OutputStream out=getContentResolver().openOutputStream(uri,"w");if(out!=null){mutable.compress(Bitmap.CompressFormat.JPEG,92,out);out.close();}source.recycle();mutable.recycle();}catch(Exception ignored){}}
    private void startRecording(){if(videoCapture==null||recordingNow)return;String name="UsTwo_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".mp4";ContentValues cv=new ContentValues();cv.put(MediaStore.MediaColumns.DISPLAY_NAME,name);cv.put(MediaStore.MediaColumns.MIME_TYPE,"video/mp4");cv.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/UsTwo");MediaStoreOutputOptions output=new MediaStoreOutputOptions.Builder(getContentResolver(),MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build();PendingRecording pending=videoCapture.getOutput().prepareRecording(this,output);if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)pending=pending.withAudioEnabled();recording=pending.start(ContextCompat.getMainExecutor(this),event->{if(event instanceof VideoRecordEvent.Start){recordingNow=true;record.setText("■ Stop");}else if(event instanceof VideoRecordEvent.Finalize){recordingNow=false;record.setText("● Video");VideoRecordEvent.Finalize fin=(VideoRecordEvent.Finalize)event;if(!fin.hasError()){lastUri=fin.getOutputResults().getOutputUri();toast("Video saved in Movies/UsTwo. Decorative effects are preview-only in video.");}else toast("Recording failed. Try again.");recording=null;}});}
    private void stopRecording(){if(recording!=null)recording.stop();}private void stopIfNeeded(){if(recording!=null)recording.stop();}
    private void playLast(){if(lastUri==null){toast("Capture a photo or video first.");return;}if(getContentResolver().getType(lastUri)!=null && getContentResolver().getType(lastUri).startsWith("image/")){Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(lastUri,"image/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);return;}play(lastUri);}
    private void play(Uri uri){cameraScreen=false;LinearLayout p=page("Review your vlog 💗");VideoView video=new VideoView(this);LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(-1,dp(420));vp.topMargin=dp(16);p.addView(video,vp);video.setVideoURI(uri);video.setOnPreparedListener(mp->video.start());p.addView(button("Share recording",()->shareUri(uri,"video/mp4")));p.addView(button("Back home",this::home));setRoot(p);}
    private void shareUri(Uri uri,String type){Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share with"));}

    private void authScreen(){LinearLayout p=page("Your UsTwo account");p.addView(text("Sign in or create an account to save private content to Firebase.",13,muted,false));spacer(p,14);EditText email=new EditText(this);email.setHint("Email address");email.setInputType(33);p.addView(email);EditText password=new EditText(this);password.setHint("Password (6+ characters)");password.setInputType(129);p.addView(password);spacer(p,10);p.addView(button("Create account",()->{String e=email.getText().toString().trim(),pw=password.getText().toString();if(e.isEmpty()||pw.length()<6){toast("Enter an email and a password with at least 6 characters.");return;}auth.createUserWithEmailAndPassword(e,pw).addOnSuccessListener(r->{toast("Account created. Add secure Firebase rules before storing private data.");home();}).addOnFailureListener(err->toast("Sign up failed: "+err.getMessage()));}));p.addView(button("Sign in",()->{String e=email.getText().toString().trim(),pw=password.getText().toString();auth.signInWithEmailAndPassword(e,pw).addOnSuccessListener(r->{toast("Signed in.");home();}).addOnFailureListener(err->toast("Sign in failed: "+err.getMessage()));}));if(auth.getCurrentUser()!=null)p.addView(button("Sign out",()->{auth.signOut();home();}));p.addView(button("Back",this::home));setRoot(p);}
    private void memories(){LinearLayout p=page("Our memories ♡");p.addView(text("Save a note to your signed-in account. These are per-account notes until partner linking is implemented.",13,muted,false));spacer(p,12);EditText title=new EditText(this);title.setHint("Memory title");p.addView(title);EditText body=new EditText(this);body.setHint("Write a memory or love note…");body.setMinLines(3);p.addView(body);spacer(p,8);p.addView(button("Save note to Firebase",()->{if(auth.getCurrentUser()==null){toast("Sign in first.");authScreen();return;}Map<String,Object> data=new HashMap<>();data.put("title",title.getText().toString().trim());data.put("body",body.getText().toString().trim());data.put("createdAt",System.currentTimeMillis());data.put("uid",auth.getCurrentUser().getUid());db.collection("users").document(auth.getCurrentUser().getUid()).collection("memories").add(data).addOnSuccessListener(r->toast("Memory saved to your account.")).addOnFailureListener(e->toast("Could not save memory: "+e.getMessage()));}));p.addView(button("Back home",this::home));setRoot(p);}

    private void bambiSpace(){LinearLayout p=page("🎵 Bambi Space");p.addView(text("A little corner for your song covers, voice memos and music moments.",14,muted,false));spacer(p,12);p.addView(button("● Record a voice memo",this::toggleVoiceMemo));p.addView(button("▶ Play last voice memo",this::playVoiceMemo));p.addView(button("↗ Share last voice memo",this::shareVoiceMemo));p.addView(button("Upload last memo to Firebase",this::uploadVoiceMemo));p.addView(button("Choose an existing audio file",this::pickAudio));p.addView(text("Upload and sharing require sign-in. Your Storage rules must restrict files to authorized users.",12,muted,false));p.addView(button("Back home",this::home));setRoot(p);}
    private void toggleVoiceMemo(){if(!voiceRecording){if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){permissionLauncher.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO});toast("Allow microphone permission, then tap record again.");return;}try{voiceFile=new File(getExternalFilesDir(null),"bambi_"+System.currentTimeMillis()+".m4a");mediaRecorder=new MediaRecorder();mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);mediaRecorder.setOutputFile(voiceFile.getAbsolutePath());mediaRecorder.prepare();mediaRecorder.start();voiceRecording=true;toast("Recording voice memo… Tap record again to stop.");}catch(Exception e){voiceRecording=false;toast("Could not start recording: "+e.getMessage());}}else{try{mediaRecorder.stop();mediaRecorder.release();mediaRecorder=null;voiceRecording=false;toast("Voice memo saved locally.");}catch(Exception e){toast("Recording could not be finalized.");}}}
    private void playVoiceMemo(){Uri audioUri=selectedAudioUri;if(audioUri==null&&voiceFile!=null&&voiceFile.exists())audioUri=androidx.core.content.FileProvider.getUriForFile(this,getPackageName()+".fileprovider",voiceFile);if(audioUri==null){toast("Record a voice memo first, or choose an audio file.");return;}Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(audioUri,"audio/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(i);}catch(Exception e){toast("No audio player found.");}}
    private void shareVoiceMemo(){Uri uri=selectedAudioUri;if(uri==null&&voiceFile!=null&&voiceFile.exists())uri=androidx.core.content.FileProvider.getUriForFile(this,getPackageName()+".fileprovider",voiceFile);if(uri==null){toast("Record a voice memo or choose an audio file first.");return;}shareUri(uri,"audio/*");}
    private final ActivityResultLauncher<String> audioPicker=registerForActivityResult(new ActivityResultContracts.GetContent(),uri->{if(uri!=null){selectedAudioUri=uri;toast("Audio selected for Bambi Space.");}});
    private void pickAudio(){audioPicker.launch("audio/*");}
    private void uploadVoiceMemo(){if(auth.getCurrentUser()==null){toast("Sign in before uploading.");authScreen();return;}final Uri source;final String fileName;if(selectedAudioUri!=null){source=selectedAudioUri;fileName="cover_"+System.currentTimeMillis()+".audio";}else if(voiceFile!=null&&voiceFile.exists()){source=Uri.fromFile(voiceFile);fileName=voiceFile.getName();}else{toast("Record a voice memo or choose an audio file first.");return;}StorageReference ref=storage.getReference().child("users/"+auth.getCurrentUser().getUid()+"/bambi/"+fileName);ref.putFile(source).addOnSuccessListener(task->ref.getDownloadUrl().addOnSuccessListener(url->{Map<String,Object> song=new HashMap<>();song.put("name",fileName);song.put("url",url.toString());song.put("createdAt",System.currentTimeMillis());song.put("uid",auth.getCurrentUser().getUid());db.collection("users").document(auth.getCurrentUser().getUid()).collection("bambiTracks").add(song).addOnSuccessListener(r->toast("Audio uploaded to your Bambi Space.")).addOnFailureListener(e->toast("Audio uploaded but metadata failed: "+e.getMessage()));})).addOnFailureListener(e->toast("Upload failed: "+e.getMessage()));}
    @Override protected void onDestroy(){stopIfNeeded();if(mediaRecorder!=null){try{mediaRecorder.release();}catch(Exception ignored){}}super.onDestroy();}
}
